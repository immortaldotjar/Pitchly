import { Navigate, Outlet } from "react-router-dom"
import { useAuth } from "../context/AuthContext"

const ProtectedRoute = ({ allowedRoles }) => {

    const { user } = useAuth()

    if (!user) return <Navigate to="/auth/signin" replace />

    if (allowedRoles && !allowedRoles.includes(user.role)) return <Navigate to="/" replace />

    return <Outlet />
}

export default ProtectedRoute