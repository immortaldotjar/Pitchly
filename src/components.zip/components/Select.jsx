const Select = ({ label, id, value, onChange, options, placeholder, className = "" }) => {
    return (
        <div className="flex flex-col gap-2">
            {label && (
                <label htmlFor={id} className="font-label-caps text-label-caps text-on-surface-variant px-1 pt-4">
                    {label}
                </label>
            )}
            <select
                id={id}
                value={value}
                onChange={onChange}
                className={`w-full px-4 py-2 bg-surface-container-low border border-outline-variant rounded-lg text-body-sm font-body-md focus:ring-0 focus:outline-none focus:border-primary transition-all duration-150 ${className}`}
            >
                {placeholder && <option value="" disabled>{placeholder}</option>}
                {options.map((option) => (
                    <option key={option} value={option}>{option}</option>
                ))}
            </select>
        </div>
    )
}

export default Select